import { useState } from "react";
import { Play, Music, ChevronDown, Skull } from "lucide-react";

const GAME_SRCDOC = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Darkness Takeover</title>
  <base href="https://cdn.jsdelivr.net/gh/waycrosspublicmedia/livediesmos/darkness-takeover/">
  <meta id="viewport" name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <meta name="apple-mobile-web-app-capable" content="yes">
  <script type="text/javascript" src="./PsychEngine.js"><\/script>
  <script>
    window.addEventListener("touchmove", function(e){e.preventDefault();},{capture:false,passive:false});
    if(typeof window.devicePixelRatio!='undefined'&&window.devicePixelRatio>2){
      var m=document.getElementById("viewport");
      m.setAttribute('content','width=device-width,initial-scale='+(2/window.devicePixelRatio)+',user-scalable=no');
    }
    window.addEventListener("keydown",function(e){if(["Tab","Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].indexOf(e.code)>-1){e.preventDefault();}},false);
  <\/script>
  <style>
    html,body{margin:0;padding:0;height:100%;overflow:hidden;background:#000;}
    #openfl-content{background:#000;width:100%;height:100%;}
  <\/style>
</head>
<body>
  <div id="openfl-content"></div>
  <script>lime.embed("PsychEngine","openfl-content",1280,720,{parameters:{}});<\/script>
</body>
</html>`;

type Difficulty = "Easy" | "Normal" | "Hard";

interface Song {
  id: number;
  title: string;
  composer: string;
  difficulty: Difficulty;
  bpm: number;
  bpmLabel?: string;
  week: string;
  color: string;
}

const SONGS: Song[] = [
  {
    id: 1,
    title: "A Family Guy",
    composer: "Corrupted Peter vs. BF",
    difficulty: "Hard",
    bpm: 144,
    bpmLabel: "144–160–144",
    week: "Official OST",
    color: "#bf00ff",
  },
  {
    id: 2,
    title: "Rooten Family",
    composer: "Corrupted Brian vs. Stewie",
    difficulty: "Hard",
    bpm: 150,
    week: "Official OST",
    color: "#00ffea",
  },
  {
    id: 3,
    title: "Fashioned Values",
    composer: "Corrupted Cleveland Brown vs. Quagmire",
    difficulty: "Hard",
    bpm: 140,
    bpmLabel: "140–160",
    week: "Official OST",
    color: "#ff003c",
  },
  {
    id: 4,
    title: "Death Lives",
    composer: "BF & Peter run",
    difficulty: "Normal",
    bpm: 135,
    bpmLabel: "135–150",
    week: "Official OST",
    color: "#bf00ff",
  },
  {
    id: 5,
    title: "Twinkle",
    composer: "Corrupted Stewie vs. Quagmire",
    difficulty: "Hard",
    bpm: 160,
    week: "Official OST",
    color: "#00ffea",
  },
  {
    id: 6,
    title: "Final Fight",
    composer: "Corrupted Chicken vs. Peter",
    difficulty: "Hard",
    bpm: 170,
    bpmLabel: "170–180",
    week: "Official OST",
    color: "#ff003c",
  },
  {
    id: 7,
    title: "Airborne",
    composer: "Peter, Cleveland, Quagmire, & Joe vs. Rallo",
    difficulty: "Hard",
    bpm: 155,
    week: "Official OST",
    color: "#bf00ff",
  },
];

const DIFF_COLORS: Record<Difficulty, string> = {
  Easy: "#00ffea",
  Normal: "#bf00ff",
  Hard: "#ff003c",
};

function GlitchText({ text, className = "" }: { text: string; className?: string }) {
  return (
    <span className={`relative inline-block ${className}`} data-text={text}>
      {text}
      <style>{`
        [data-text]::before,
        [data-text]::after {
          content: attr(data-text);
          position: absolute;
          inset: 0;
          pointer-events: none;
        }
        [data-text]::before {
          animation: glitch-1 3.2s infinite steps(1);
          clip-path: polygon(0 20%, 100% 20%, 100% 40%, 0 40%);
          color: #00ffea;
          left: -2px;
          opacity: 0.8;
        }
        [data-text]::after {
          animation: glitch-2 2.7s infinite steps(1);
          clip-path: polygon(0 60%, 100% 60%, 100% 80%, 0 80%);
          color: #ff003c;
          left: 2px;
          opacity: 0.8;
        }
        @keyframes glitch-1 {
          0%,80%,100% { transform: translateX(0); opacity: 0; }
          82% { transform: translateX(-3px); opacity: 0.8; }
          84% { transform: translateX(3px); opacity: 0.8; }
          86% { transform: translateX(0); opacity: 0; }
        }
        @keyframes glitch-2 {
          0%,70%,100% { transform: translateX(0); opacity: 0; }
          72% { transform: translateX(3px); opacity: 0.8; }
          74% { transform: translateX(-2px); opacity: 0.8; }
          76% { transform: translateX(0); opacity: 0; }
        }
      `}</style>
    </span>
  );
}

function ScanlineOverlay() {
  return (
    <div
      className="pointer-events-none fixed inset-0 z-10"
      style={{
        background:
          "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.07) 2px, rgba(0,0,0,0.07) 4px)",
      }}
    />
  );
}

function NeonBorder({ className = "" }: { className?: string }) {
  return (
    <div
      className={`absolute inset-0 rounded-[inherit] pointer-events-none ${className}`}
      style={{
        boxShadow:
          "inset 0 0 0 1px rgba(191,0,255,0.4), 0 0 20px rgba(191,0,255,0.15)",
      }}
    />
  );
}

export default function App() {
  const [gameActive, setGameActive] = useState(false);
  const [selectedSong, setSelectedSong] = useState<Song | null>(null);
  const [filterWeek, setFilterWeek] = useState<string>("All");

  const weeks = ["All", ...Array.from(new Set(SONGS.map((s) => s.week)))];
  const hasMultipleWeeks = weeks.length > 2;
  const filtered =
    filterWeek === "All" ? SONGS : SONGS.filter((s) => s.week === filterWeek);

  return (
    <div
      className="min-h-screen bg-background text-foreground overflow-x-hidden"
      style={{ fontFamily: "'Chakra Petch', sans-serif" }}
    >
      <ScanlineOverlay />

      {/* Ambient background glows */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div
          className="absolute top-[-20%] left-[-10%] w-[60vw] h-[60vw] rounded-full opacity-10"
          style={{
            background: "radial-gradient(circle, #bf00ff 0%, transparent 70%)",
          }}
        />
        <div
          className="absolute bottom-[-10%] right-[-10%] w-[50vw] h-[50vw] rounded-full opacity-8"
          style={{
            background: "radial-gradient(circle, #00ffea 0%, transparent 70%)",
          }}
        />
      </div>

      {/* ── HERO ── */}
      <header className="relative z-20 flex flex-col items-center justify-center pt-16 pb-8 px-6 text-center">
        <div className="flex items-center gap-3 mb-4">
          <Skull
            className="w-6 h-6"
            style={{ color: "#bf00ff", filter: "drop-shadow(0 0 6px #bf00ff)" }}
          />
          <span
            className="text-xs tracking-[0.4em] uppercase"
            style={{ color: "#8860c0", fontFamily: "'Chakra Petch', sans-serif" }}
          >
            Friday Night Funkin&apos;
          </span>
          <Skull
            className="w-6 h-6"
            style={{ color: "#bf00ff", filter: "drop-shadow(0 0 6px #bf00ff)" }}
          />
        </div>

        <h1
          className="text-3xl md:text-5xl lg:text-6xl leading-tight mb-6 uppercase"
          style={{
            fontFamily: "'Press Start 2P', monospace",
            color: "#f0e8ff",
            textShadow:
              "0 0 20px rgba(191,0,255,0.8), 0 0 40px rgba(191,0,255,0.4), 0 0 80px rgba(191,0,255,0.2)",
            letterSpacing: "0.05em",
          }}
        >
          <GlitchText text="DARKNESS" />
          <br />
          <span style={{ color: "#00ffea", textShadow: "0 0 20px rgba(0,255,234,0.8)" }}>
            <GlitchText text="TAKEOVER" />
          </span>
        </h1>

        <p
          className="max-w-lg text-sm md:text-base leading-relaxed mb-8"
          style={{ color: "#8860c0" }}
        >
          The shadows have consumed everything. Can you beat the dark? Play the full
          mod below or browse the freeplay setlist.
        </p>

        <div className="flex flex-col sm:flex-row gap-4">
          <a
            href="#game"
            onClick={() => setGameActive(true)}
            className="inline-flex items-center gap-2 px-8 py-3 text-sm uppercase tracking-widest transition-all duration-200 cursor-pointer"
            style={{
              fontFamily: "'Press Start 2P', monospace",
              fontSize: "10px",
              background: "#bf00ff",
              color: "#fff",
              boxShadow: "0 0 20px rgba(191,0,255,0.6), 0 0 40px rgba(191,0,255,0.3)",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.boxShadow =
                "0 0 30px rgba(191,0,255,0.9), 0 0 60px rgba(191,0,255,0.5)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.boxShadow =
                "0 0 20px rgba(191,0,255,0.6), 0 0 40px rgba(191,0,255,0.3)";
            }}
          >
            <Play className="w-3 h-3 fill-current" />
            Play Now
          </a>
          <a
            href="#freeplay"
            className="inline-flex items-center gap-2 px-8 py-3 text-sm uppercase tracking-widest transition-all duration-200 cursor-pointer"
            style={{
              fontFamily: "'Press Start 2P', monospace",
              fontSize: "10px",
              border: "1px solid rgba(0,255,234,0.5)",
              color: "#00ffea",
              boxShadow: "0 0 10px rgba(0,255,234,0.2)",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.boxShadow =
                "0 0 20px rgba(0,255,234,0.4)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.boxShadow =
                "0 0 10px rgba(0,255,234,0.2)";
            }}
          >
            <Music className="w-3 h-3" />
            Freeplay
          </a>
        </div>

        <div
          className="mt-12 animate-bounce"
          style={{ color: "rgba(136,96,192,0.5)" }}
        >
          <ChevronDown className="w-5 h-5" />
        </div>
      </header>

      {/* ── GAME EMBED ── */}
      <section id="game" className="relative z-20 px-4 md:px-8 mb-16">
        <div className="max-w-6xl mx-auto">
          <div
            className="relative w-full"
            style={{
              aspectRatio: "16/9",
              background: "#000",
              boxShadow:
                "0 0 0 1px rgba(191,0,255,0.4), 0 0 40px rgba(191,0,255,0.2), 0 0 80px rgba(191,0,255,0.1)",
            }}
          >
            {!gameActive ? (
              <button
                onClick={() => setGameActive(true)}
                className="absolute inset-0 flex flex-col items-center justify-center gap-6 group w-full h-full cursor-pointer"
                style={{ background: "rgba(4,0,10,0.85)" }}
              >
                <div
                  className="w-20 h-20 rounded-full flex items-center justify-center transition-all duration-300 group-hover:scale-110"
                  style={{
                    background: "rgba(191,0,255,0.15)",
                    border: "2px solid rgba(191,0,255,0.6)",
                    boxShadow: "0 0 30px rgba(191,0,255,0.4)",
                  }}
                >
                  <Play
                    className="w-8 h-8 fill-current ml-1"
                    style={{ color: "#bf00ff" }}
                  />
                </div>
                <span
                  className="text-xs tracking-widest uppercase"
                  style={{
                    fontFamily: "'Press Start 2P', monospace",
                    color: "#8860c0",
                  }}
                >
                  Click to Load Game
                </span>
              </button>
            ) : (
              <iframe
                srcdoc={GAME_SRCDOC}
                title="Friday Night Funkin' — Darkness Takeover"
                className="absolute inset-0 w-full h-full border-0"
                allow="autoplay; fullscreen"
                sandbox="allow-scripts allow-same-origin allow-popups allow-forms"
              />
            )}

            {/* corner accents */}
            {["top-0 left-0", "top-0 right-0", "bottom-0 left-0", "bottom-0 right-0"].map(
              (pos, i) => (
                <div
                  key={i}
                  className={`absolute ${pos} w-6 h-6 pointer-events-none`}
                  style={{
                    borderTop: i < 2 ? "2px solid #bf00ff" : "none",
                    borderBottom: i >= 2 ? "2px solid #bf00ff" : "none",
                    borderLeft: i % 2 === 0 ? "2px solid #bf00ff" : "none",
                    borderRight: i % 2 === 1 ? "2px solid #bf00ff" : "none",
                    filter: "drop-shadow(0 0 4px #bf00ff)",
                  }}
                />
              )
            )}
          </div>

          <div className="flex items-center justify-between mt-3 px-1">
            <p className="text-xs" style={{ color: "#8860c0" }}>
              Use arrow keys or WASD to play. Press Enter to confirm.
            </p>
          </div>
        </div>
      </section>

      {/* ── DIVIDER ── */}
      <div className="relative z-20 max-w-6xl mx-auto px-4 md:px-8 mb-16">
        <div
          className="h-px"
          style={{
            background:
              "linear-gradient(90deg, transparent, rgba(191,0,255,0.6), rgba(0,255,234,0.4), transparent)",
          }}
        />
      </div>

      {/* ── FREEPLAY ── */}
      <section id="freeplay" className="relative z-20 px-4 md:px-8 pb-24">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-10">
            <div>
              <p
                className="text-xs tracking-[0.4em] uppercase mb-2"
                style={{ color: "#8860c0" }}
              >
                Song Browser
              </p>
              <h2
                className="text-xl md:text-2xl uppercase"
                style={{
                  fontFamily: "'Press Start 2P', monospace",
                  color: "#f0e8ff",
                  textShadow: "0 0 10px rgba(191,0,255,0.5)",
                  lineHeight: 1.4,
                }}
              >
                Freeplay
              </h2>
            </div>

            {/* week filter — only shown when there are multiple weeks */}
            {hasMultipleWeeks && (
              <div className="flex flex-wrap gap-2">
                {weeks.map((w) => (
                  <button
                    key={w}
                    onClick={() => setFilterWeek(w)}
                    className="px-4 py-1.5 text-xs uppercase tracking-widest transition-all duration-150"
                    style={{
                      fontFamily: "'Chakra Petch', sans-serif",
                      fontWeight: 600,
                      background: filterWeek === w ? "#bf00ff" : "transparent",
                      color: filterWeek === w ? "#fff" : "#8860c0",
                      border:
                        filterWeek === w
                          ? "1px solid #bf00ff"
                          : "1px solid rgba(191,0,255,0.25)",
                      boxShadow:
                        filterWeek === w ? "0 0 12px rgba(191,0,255,0.5)" : "none",
                    }}
                  >
                    {w}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* song grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map((song) => (
              <button
                key={song.id}
                onClick={() =>
                  setSelectedSong(selectedSong?.id === song.id ? null : song)
                }
                className="relative text-left p-5 transition-all duration-200 group"
                style={{
                  background:
                    selectedSong?.id === song.id
                      ? "rgba(191,0,255,0.1)"
                      : "rgba(12,0,20,0.8)",
                  border:
                    selectedSong?.id === song.id
                      ? `1px solid ${song.color}`
                      : "1px solid rgba(191,0,255,0.2)",
                  boxShadow:
                    selectedSong?.id === song.id
                      ? `0 0 20px ${song.color}40`
                      : "none",
                }}
                onMouseEnter={(e) => {
                  if (selectedSong?.id !== song.id) {
                    (e.currentTarget as HTMLElement).style.borderColor =
                      `${song.color}80`;
                    (e.currentTarget as HTMLElement).style.background =
                      "rgba(191,0,255,0.05)";
                  }
                }}
                onMouseLeave={(e) => {
                  if (selectedSong?.id !== song.id) {
                    (e.currentTarget as HTMLElement).style.borderColor =
                      "rgba(191,0,255,0.2)";
                    (e.currentTarget as HTMLElement).style.background =
                      "rgba(12,0,20,0.8)";
                  }
                }}
              >
                {/* accent line */}
                <div
                  className="absolute top-0 left-0 right-0 h-0.5"
                  style={{
                    background: song.color,
                    boxShadow: `0 0 8px ${song.color}`,
                    opacity: selectedSong?.id === song.id ? 1 : 0.4,
                  }}
                />

                <div className="flex items-start justify-between mb-3">
                  <span
                    className="text-xs px-2 py-0.5 uppercase tracking-widest"
                    style={{
                      fontFamily: "'Chakra Petch', sans-serif",
                      fontWeight: 700,
                      color: DIFF_COLORS[song.difficulty],
                      border: `1px solid ${DIFF_COLORS[song.difficulty]}40`,
                      background: `${DIFF_COLORS[song.difficulty]}10`,
                    }}
                  >
                    {song.difficulty}
                  </span>
                  <span className="text-xs" style={{ color: "#8860c0" }}>
                    {song.week}
                  </span>
                </div>

                <h3
                  className="text-base mb-1 uppercase"
                  style={{
                    fontFamily: "'Press Start 2P', monospace",
                    fontSize: "11px",
                    color: "#f0e8ff",
                    lineHeight: 1.6,
                    textShadow:
                      selectedSong?.id === song.id
                        ? `0 0 10px ${song.color}`
                        : "none",
                  }}
                >
                  {song.title}
                </h3>
                <p className="text-xs mb-3" style={{ color: "#8860c0" }}>
                  {song.composer}
                </p>

                <div className="flex items-center gap-4 text-xs" style={{ color: "#8860c0" }}>
                  <span className="flex items-center gap-1">
                    <span style={{ color: song.color }}>♩</span>
                    {song.bpmLabel ?? song.bpm} BPM
                  </span>
                </div>
              </button>
            ))}
          </div>

          {/* selected song note */}
          {selectedSong && (
            <div
              className="mt-6 p-4 text-sm"
              style={{
                border: "1px solid rgba(0,255,234,0.3)",
                background: "rgba(0,255,234,0.05)",
                color: "#00ffea",
              }}
            >
              <span style={{ fontFamily: "'Press Start 2P', monospace", fontSize: "9px" }}>
                ▶ {selectedSong.title}
              </span>
              <span className="ml-3" style={{ color: "#8860c0", fontFamily: "'Chakra Petch', sans-serif" }}>
                — Select this song inside the game&apos;s Freeplay menu to play it.
              </span>
            </div>
          )}

          {/* info box */}
          <div
            className="mt-10 p-5 text-sm"
            style={{
              border: "1px solid rgba(191,0,255,0.2)",
              background: "rgba(12,0,20,0.6)",
              color: "#8860c0",
            }}
          >
            <p className="mb-1" style={{ color: "#c8a8ff", fontWeight: 600 }}>
              Adding custom songs
            </p>
            <p className="leading-relaxed text-xs">
              To add your own songs so they appear in the in-game Freeplay menu, you need
              to add their chart JSON files and audio assets to the game folder, then
              register them in the game&apos;s song list config. Drop your song folders
              into <code className="px-1" style={{ background: "rgba(191,0,255,0.15)", color: "#bf00ff" }}>assets/songs/</code> and
              update <code className="px-1" style={{ background: "rgba(191,0,255,0.15)", color: "#bf00ff" }}>data/freeplaySonglist.txt</code> with
              each song name — then re-host your modified build.
            </p>
          </div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer
        className="relative z-20 border-t px-4 py-8 text-center"
        style={{ borderColor: "rgba(191,0,255,0.2)" }}
      >
        <p
          className="text-xs uppercase tracking-widest"
          style={{ fontFamily: "'Press Start 2P', monospace", fontSize: "8px", color: "#3a0060" }}
        >
          Darkness Takeover — A Friday Night Funkin&apos; Mod
        </p>
      </footer>
    </div>
  );
}
